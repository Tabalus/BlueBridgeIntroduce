for num in range(10, 100):
    print(str(num) + str(num)[::-1])

print(str(hex(int(input()))).replace("0x", "", 1).upper())

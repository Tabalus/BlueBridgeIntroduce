n = int(input())
nums = list(map(int, input().split())).sort()
for i in nums:
    print(i, end=" ")

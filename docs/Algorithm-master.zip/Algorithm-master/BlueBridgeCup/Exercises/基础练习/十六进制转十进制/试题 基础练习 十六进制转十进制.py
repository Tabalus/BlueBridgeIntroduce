print(int(input(), 16))

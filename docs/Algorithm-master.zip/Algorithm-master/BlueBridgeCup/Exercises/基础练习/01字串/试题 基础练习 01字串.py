for i in range(2):
    for j in range(2):
        for k in range(2):
            for l in range(2):
                for m in range(2):
                    print("%s%s%s%s%s" % (i, j, k, l, m))

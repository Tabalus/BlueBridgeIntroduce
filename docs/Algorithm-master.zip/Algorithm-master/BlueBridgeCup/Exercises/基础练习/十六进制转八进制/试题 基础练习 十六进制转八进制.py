for _ in range(int(input())):
    print(str(oct(int(input(), 16))).replace("0o", "", 1))

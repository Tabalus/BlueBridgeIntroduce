import math


r = int(input())
area = math.pi * r * r
print("%.7f" % area)

n = int(input())
print((n + 1) * int(n / 2) if n > 1 else 1)

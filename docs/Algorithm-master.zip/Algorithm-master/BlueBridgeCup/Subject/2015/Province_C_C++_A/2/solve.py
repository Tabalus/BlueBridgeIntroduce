import datetime

start = datetime.date(2014, 11, 9)
print(start + datetime.timedelta(days=1000))

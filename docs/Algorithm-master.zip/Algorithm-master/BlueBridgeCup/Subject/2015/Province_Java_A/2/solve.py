import datetime

if __name__ == '__main__':
    start = datetime.date(2014, 11, 9)
    print(start + datetime.timedelta(1000))

if __name__ == '__main__':
    cnt = 0
    for i in range(21, 50, 2):
        cnt += 1
    print(cnt)

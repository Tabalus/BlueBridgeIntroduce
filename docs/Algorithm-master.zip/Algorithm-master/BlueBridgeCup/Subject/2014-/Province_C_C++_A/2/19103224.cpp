#include <iostream>

using namespace std;

int main()
{
	int x = 2;
	for(int i=1;i<=10;i++)
	{
		x = 2 * x - 1;
	}
	cout << x << endl;
	return 0;
}

index, summ = 1, 0
while summ < 15:
    summ += 1 / index
    index += 1
print(f"index = {index - 1}, summ = {summ}")

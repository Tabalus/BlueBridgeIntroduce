import math


if __name__ == '__main__':
    num = 16
    print(math.comb(2 * num, num) // (num + 1))

if __name__ == '__main__':
    week = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']
    print(week[(651764141421415346185 % len(week)) - 1])

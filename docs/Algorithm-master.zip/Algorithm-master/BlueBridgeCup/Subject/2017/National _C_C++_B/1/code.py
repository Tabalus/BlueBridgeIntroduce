print(int("MANY", 36))

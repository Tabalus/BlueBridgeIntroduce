N, M = map(int, input().split())
print(N, M)

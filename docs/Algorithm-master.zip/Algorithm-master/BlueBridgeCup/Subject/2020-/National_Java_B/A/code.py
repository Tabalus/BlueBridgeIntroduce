cnt = 0
for i in range(1, 2021):
    if '2' in str(i):
        cnt += 1
print(cnt)

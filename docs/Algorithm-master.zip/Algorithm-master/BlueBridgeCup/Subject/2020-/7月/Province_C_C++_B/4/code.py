A = 0
for _ in range(2):
    A = A + 4
    for _ in range(5):
        for _ in range(6):
            A = A + 5
        A = A + 7
    for _ in range(6):
        A = A + 7
        for _ in range(4):
            A = A + 2
            A = A + 7
        A = A + 2
    for _ in range(7):
        for _ in range(4):
            A = A + 8
            A = A + 7
            A = A + 4
            A = A + 5
        A = A + 8
    for _ in range(8):
        A = A + 5
        for _ in range(1):
            A = A + 2
        for _ in range(7):
            A = A + 5
        A = A + 5
    for _ in range(2):
        for _ in range(3):
            A = A + 1
        A = A + 1
    for _ in range(5):
        A = A + 1
    for _ in range(9):
        for _ in range(6):
            A = A + 5
            A = A + 1
        for _ in range(6):
            A = A + 2
            A = A + 8
            A = A + 3
        for _ in range(2):
            A = A + 5
        for _ in range(3):
            A = A + 9
        for _ in range(1):
            A = A + 4
        for _ in range(2):
            A = A + 9
        for _ in range(1):
            A = A + 6
            A = A + 6
            A = A + 4
        for _ in range(3):
            A = A + 7
        A = A + 1
        for _ in range(2):
            A = A + 3
        for _ in range(5):
            A = A + 2
            A = A + 5
            A = A + 2
        A = A + 4
    A = A + 3
for _ in range(4):
    A = A + 4
    A = A + 3
    A = A + 7
    for _ in range(5):
        for _ in range(4):
            A = A + 5
            A = A + 7
        for _ in range(5):
            A = A + 3
        for _ in range(3):
            A = A + 3
            A = A + 1
        A = A + 8
        A = A + 2
        for _ in range(9):
            A = A + 5
        for _ in range(1):
            A = A + 5
        A = A + 2
    A = A + 8
A = A + 6
for _ in range(3):
    for _ in range(4):
        A = A + 9
        for _ in range(5):
            A = A + 2
        A = A + 1
    for _ in range(9):
        A = A + 9
        A = A + 2
        for _ in range(1):
            A = A + 6
            A = A + 8
        for _ in range(2):
            A = A + 9
            A = A + 4
        A = A + 7
    for _ in range(2):
        for _ in range(7):
            A = A + 3
            A = A + 5
        for _ in range(3):
            A = A + 5
            A = A + 3
            A = A + 6
            A = A + 4
        for _ in range(9):
            A = A + 2
            A = A + 8
            A = A + 2
        A = A + 3
    for _ in range(2):
        for _ in range(8):
            A = A + 5
            A = A + 1
        A = A + 6
        A = A + 1
    A = A + 2
    for _ in range(6):
        for _ in range(1):
            A = A + 3
        for _ in range(1):
            A = A + 2
        for _ in range(4):
            A = A + 7
            A = A + 1
        A = A + 8
        for _ in range(6):
            A = A + 5
        for _ in range(6):
            A = A + 3
        for _ in range(2):
            A = A + 2
            A = A + 9
        A = A + 7
    for _ in range(9):
        A = A + 8
        for _ in range(9):
            A = A + 8
            A = A + 9
            A = A + 3
        A = A + 2
        for _ in range(6):
            A = A + 3
        for _ in range(9):
            A = A + 1
        A = A + 9
        A = A + 5
        for _ in range(2):
            A = A + 4
            A = A + 9
        A = A + 8
        for _ in range(5):
            A = A + 6
            A = A + 9
        A = A + 1
    for _ in range(1):
        A = A + 4
    A = A + 2
    for _ in range(9):
        for _ in range(3):
            A = A + 4
        for _ in range(7):
            A = A + 8
            A = A + 3
        for _ in range(5):
            A = A + 9
        for _ in range(8):
            A = A + 9
            A = A + 8
        for _ in range(4):
            A = A + 7
        A = A + 7
    A = A + 3
A = A + 5
for _ in range(6):
    A = A + 7
for _ in range(7):
    A = A + 2
    A = A + 2
A = A + 1
for _ in range(8):
    for _ in range(1):
        for _ in range(4):
            A = A + 6
            A = A + 6
            A = A + 2
        for _ in range(5):
            A = A + 4
            A = A + 8
            A = A + 4
        for _ in range(1):
            A = A + 5
        for _ in range(7):
            A = A + 8
        for _ in range(6):
            A = A + 4
        A = A + 4
        A = A + 8
        for _ in range(4):
            A = A + 2
        for _ in range(2):
            A = A + 4
        for _ in range(2):
            A = A + 3
        for _ in range(1):
            A = A + 2
        A = A + 8
        for _ in range(2):
            A = A + 7
        for _ in range(8):
            A = A + 6
            A = A + 1
        A = A + 7
    for _ in range(8):
        A = A + 2
    for _ in range(8):
        for _ in range(6):
            A = A + 1
            A = A + 6
        for _ in range(2):
            A = A + 4
            A = A + 1
        A = A + 7
    A = A + 4
for _ in range(4):
    for _ in range(9):
        A = A + 2
    for _ in range(1):
        A = A + 2
    A = A + 5
for _ in range(8):
    for _ in range(6):
        A = A + 3
    for _ in range(4):
        A = A + 1
        A = A + 6
        A = A + 1
    for _ in range(7):
        A = A + 7
        for _ in range(7):
            A = A + 3
            A = A + 9
            A = A + 1
            A = A + 9
        for _ in range(3):
            A = A + 5
        A = A + 5
        A = A + 6
        A = A + 2
    for _ in range(1):
        A = A + 4
    for _ in range(2):
        A = A + 7
    for _ in range(1):
        A = A + 7
        for _ in range(4):
            A = A + 7
        A = A + 2
        for _ in range(5):
            A = A + 9
            A = A + 1
            A = A + 9
            A = A + 5
            A = A + 9
        for _ in range(5):
            A = A + 5
        for _ in range(1):
            A = A + 6
        for _ in range(2):
            A = A + 3
            A = A + 2
            A = A + 6
            A = A + 8
            A = A + 8
            A = A + 7
        A = A + 5
    A = A + 5
for _ in range(2):
    A = A + 1
    A = A + 7
A = A + 3
for _ in range(2):
    A = A + 7
A = A + 1
A = A + 4
for _ in range(1):
    for _ in range(7):
        for _ in range(2):
            A = A + 3
            A = A + 5
            A = A + 2
        A = A + 6
    A = A + 1
A = A + 2
A = A + 4
A = A + 9
for _ in range(1):
    A = A + 8
for _ in range(8):
    for _ in range(4):
        for _ in range(8):
            A = A + 4
        for _ in range(3):
            A = A + 1
            A = A + 8
        for _ in range(7):
            A = A + 8
        for _ in range(7):
            A = A + 7
        A = A + 7
        for _ in range(7):
            A = A + 6
        for _ in range(5):
            A = A + 9
        A = A + 3
        for _ in range(4):
            A = A + 5
        A = A + 5
    A = A + 4
    for _ in range(9):
        for _ in range(3):
            A = A + 4
            A = A + 3
            A = A + 6
        for _ in range(1):
            A = A + 3
            A = A + 3
            A = A + 6
        for _ in range(6):
            A = A + 7
            A = A + 7
            A = A + 5
            A = A + 5
            A = A + 1
            A = A + 2
        A = A + 6
        A = A + 6
    for _ in range(9):
        A = A + 6
    for _ in range(1):
        for _ in range(2):
            A = A + 4
            A = A + 7
        for _ in range(3):
            A = A + 6
        for _ in range(5):
            A = A + 3
        A = A + 6
        for _ in range(9):
            A = A + 3
        A = A + 6
    for _ in range(5):
        A = A + 8
        A = A + 8
        for _ in range(3):
            A = A + 7
            A = A + 9
            A = A + 8
            A = A + 3
        A = A + 3
    A = A + 9
for _ in range(6):
    A = A + 9
A = A + 1
for _ in range(4):
    for _ in range(1):
        A = A + 7
    for _ in range(9):
        A = A + 2
        A = A + 9
    A = A + 1
A = A + 2
A = A + 8
A = A + 7
A = A + 9
A = A + 6
for _ in range(4):
    for _ in range(2):
        A = A + 3
    for _ in range(3):
        A = A + 4
    A = A + 4
for _ in range(6):
    A = A + 6
A = A + 1
A = A + 5
A = A + 8
for _ in range(2):
    A = A + 6
    for _ in range(1):
        for _ in range(2):
            A = A + 2
        for _ in range(3):
            A = A + 1
        for _ in range(1):
            A = A + 8
            A = A + 7
            A = A + 4
            A = A + 2
            A = A + 8
        A = A + 4
    for _ in range(5):
        for _ in range(6):
            A = A + 8
        for _ in range(9):
            A = A + 5
        A = A + 5
    for _ in range(5):
        A = A + 5
    for _ in range(3):
        for _ in range(5):
            A = A + 4
        for _ in range(4):
            A = A + 6
            A = A + 3
        for _ in range(7):
            A = A + 3
            A = A + 3
            A = A + 1
            A = A + 7
            A = A + 7
            A = A + 6
            A = A + 5
            A = A + 5
        A = A + 6
    for _ in range(1):
        A = A + 9
    A = A + 3
    for _ in range(1):
        for _ in range(1):
            A = A + 1
        for _ in range(8):
            A = A + 5
        for _ in range(8):
            A = A + 6
        for _ in range(4):
            A = A + 9
        A = A + 4
    for _ in range(2):
        A = A + 3
        A = A + 7
        for _ in range(5):
            A = A + 7
            A = A + 5
            A = A + 8
        A = A + 7
        A = A + 8
    A = A + 5
    for _ in range(2):
        A = A + 5
    A = A + 7
    A = A + 8
A = A + 5
A = A + 9
for _ in range(2):
    for _ in range(6):
        A = A + 9
        A = A + 1
        A = A + 8
        A = A + 7
        A = A + 1
        A = A + 5
    for _ in range(3):
        A = A + 3
        A = A + 9
        A = A + 7
    for _ in range(3):
        A = A + 9
    A = A + 1
    for _ in range(6):
        A = A + 1
    for _ in range(9):
        for _ in range(7):
            A = A + 3
        for _ in range(5):
            A = A + 5
            A = A + 8
            A = A + 8
            A = A + 1
            A = A + 2
        for _ in range(4):
            A = A + 6
        for _ in range(3):
            A = A + 3
        A = A + 7
    for _ in range(8):
        for _ in range(1):
            A = A + 7
        A = A + 8
        A = A + 3
    A = A + 1
A = A + 2
A = A + 4
A = A + 7
for _ in range(1):
    for _ in range(1):
        for _ in range(1):
            A = A + 4
            A = A + 6
        for _ in range(1):
            A = A + 3
            A = A + 9
            A = A + 6
        for _ in range(9):
            A = A + 1
            A = A + 6
        for _ in range(5):
            A = A + 3
            A = A + 9
        A = A + 5
        A = A + 5
    A = A + 7
    A = A + 2
    for _ in range(2):
        A = A + 7
    A = A + 7
    for _ in range(7):
        for _ in range(4):
            A = A + 6
        A = A + 8
        for _ in range(6):
            A = A + 6
        for _ in range(2):
            A = A + 1
        A = A + 7
        A = A + 6
    A = A + 7
    for _ in range(4):
        for _ in range(7):
            A = A + 1
        for _ in range(2):
            A = A + 2
            A = A + 5
        A = A + 8
    A = A + 2
A = A + 1
A = A + 4
for _ in range(8):
    A = A + 5
A = A + 6
for _ in range(7):
    for _ in range(6):
        for _ in range(9):
            A = A + 7
            A = A + 8
        for _ in range(4):
            A = A + 6
            A = A + 4
            A = A + 3
            A = A + 6
        for _ in range(9):
            A = A + 3
        for _ in range(9):
            A = A + 2
        A = A + 7
    A = A + 5
    A = A + 2
for _ in range(7):
    for _ in range(8):
        for _ in range(6):
            A = A + 4
            A = A + 9
            A = A + 5
            A = A + 3
        A = A + 9
    for _ in range(4):
        for _ in range(1):
            A = A + 6
            A = A + 8
        for _ in range(1):
            A = A + 6
        A = A + 4
        A = A + 6
    for _ in range(3):
        A = A + 7
        for _ in range(3):
            A = A + 4
            A = A + 4
            A = A + 2
        A = A + 3
        A = A + 7
    for _ in range(5):
        A = A + 6
        A = A + 5
    for _ in range(1):
        for _ in range(8):
            A = A + 5
        for _ in range(3):
            A = A + 6
        for _ in range(9):
            A = A + 4
        A = A + 3
    for _ in range(6):
        for _ in range(2):
            A = A + 1
        A = A + 5
    A = A + 2
A = A + 2
A = A + 7
for _ in range(4):
    A = A + 7
A = A + 9
A = A + 2
for _ in range(8):
    A = A + 9
    for _ in range(9):
        for _ in range(2):
            A = A + 3
            A = A + 2
            A = A + 1
            A = A + 5
        for _ in range(9):
            A = A + 1
            A = A + 3
        A = A + 9
        for _ in range(7):
            A = A + 2
        for _ in range(5):
            A = A + 9
            A = A + 3
        for _ in range(2):
            A = A + 4
        for _ in range(8):
            A = A + 9
        for _ in range(5):
            A = A + 5
            A = A + 4
        A = A + 2
    A = A + 4
    for _ in range(6):
        A = A + 2
        for _ in range(5):
            A = A + 7
            A = A + 7
            A = A + 8
            A = A + 3
        for _ in range(8):
            A = A + 2
            A = A + 5
        for _ in range(1):
            A = A + 8
            A = A + 5
            A = A + 1
            A = A + 1
        A = A + 5
        for _ in range(2):
            A = A + 6
        for _ in range(6):
            A = A + 9
            A = A + 2
        A = A + 5
        for _ in range(4):
            A = A + 7
        A = A + 1
        for _ in range(6):
            A = A + 8
        A = A + 4
    for _ in range(3):
        for _ in range(2):
            A = A + 1
            A = A + 5
        for _ in range(2):
            A = A + 7
        for _ in range(9):
            A = A + 6
            A = A + 8
            A = A + 9
        A = A + 5
    for _ in range(9):
        for _ in range(3):
            A = A + 7
            A = A + 7
        A = A + 9
        A = A + 7
        for _ in range(5):
            A = A + 7
            A = A + 2
        A = A + 1
    A = A + 8
    A = A + 3
    A = A + 5
A = A + 1
for _ in range(8):
    A = A + 4
A = A + 2
A = A + 2
A = A + 8
for _ in range(4):
    for _ in range(4):
        A = A + 8
        for _ in range(7):
            A = A + 5
            A = A + 2
        for _ in range(2):
            A = A + 6
        for _ in range(4):
            A = A + 8
            A = A + 6
        A = A + 1
    A = A + 3
A = A + 2
A = A + 7
A = A + 4
for _ in range(8):
    A = A + 2
    A = A + 4
for _ in range(5):
    for _ in range(3):
        for _ in range(6):
            A = A + 8
            A = A + 1
        A = A + 6
    A = A + 5
    A = A + 9
for _ in range(8):
    A = A + 7
for _ in range(6):
    A = A + 4
A = A + 5
for _ in range(3):
    A = A + 1
    for _ in range(1):
        for _ in range(5):
            A = A + 6
        A = A + 2
    for _ in range(9):
        for _ in range(5):
            A = A + 9
            A = A + 3
        for _ in range(9):
            A = A + 9
        A = A + 8
    for _ in range(8):
        for _ in range(5):
            A = A + 9
            A = A + 4
        for _ in range(9):
            A = A + 3
        A = A + 4
    A = A + 5
for _ in range(9):
    for _ in range(7):
        A = A + 5
    for _ in range(3):
        A = A + 7
    for _ in range(9):
        for _ in range(6):
            A = A + 4
        A = A + 6
    for _ in range(5):
        for _ in range(6):
            A = A + 5
            A = A + 3
        A = A + 3
    A = A + 3
    A = A + 5
    for _ in range(7):
        A = A + 5
        for _ in range(2):
            A = A + 5
            A = A + 6
        for _ in range(2):
            A = A + 2
        A = A + 5
    A = A + 3
A = A + 5
A = A + 5
for _ in range(4):
    A = A + 2
    A = A + 1
    for _ in range(9):
        A = A + 9
        A = A + 5
        A = A + 6
        A = A + 2
        A = A + 2
        A = A + 5
    for _ in range(9):
        A = A + 5
    A = A + 4
    for _ in range(4):
        for _ in range(4):
            A = A + 1
            A = A + 2
        for _ in range(6):
            A = A + 9
            A = A + 3
        for _ in range(2):
            A = A + 5
            A = A + 1
            A = A + 1
            A = A + 3
        A = A + 8
        for _ in range(7):
            A = A + 4
        for _ in range(6):
            A = A + 9
        for _ in range(5):
            A = A + 9
            A = A + 8
            A = A + 3
        A = A + 9
        A = A + 4
    A = A + 6
for _ in range(7):
    A = A + 9
for _ in range(9):
    A = A + 4
    A = A + 9
    A = A + 1
    A = A + 3
    for _ in range(5):
        for _ in range(1):
            A = A + 4
            A = A + 4
        for _ in range(8):
            A = A + 9
            A = A + 6
            A = A + 2
        for _ in range(3):
            A = A + 4
            A = A + 4
        for _ in range(3):
            A = A + 5
            A = A + 2
            A = A + 8
            A = A + 3
            A = A + 6
            A = A + 4
            A = A + 9
            A = A + 1
        A = A + 9
        A = A + 5
        A = A + 3
        for _ in range(3):
            A = A + 2
            A = A + 5
            A = A + 8
            A = A + 2
        A = A + 5
    for _ in range(8):
        for _ in range(2):
            A = A + 6
        A = A + 7
    A = A + 6
    A = A + 9
    A = A + 2
for _ in range(2):
    A = A + 3
    for _ in range(8):
        A = A + 7
        A = A + 2
        A = A + 1
        A = A + 4
        A = A + 1
        A = A + 5
    A = A + 2
    A = A + 1
    for _ in range(1):
        A = A + 1
    for _ in range(6):
        A = A + 4
        A = A + 3
    A = A + 3
    for _ in range(5):
        A = A + 3
    for _ in range(6):
        for _ in range(1):
            A = A + 5
            A = A + 7
            A = A + 7
            A = A + 7
        for _ in range(5):
            A = A + 9
        A = A + 7
        for _ in range(5):
            A = A + 9
            A = A + 1
            A = A + 9
        A = A + 8
        for _ in range(1):
            A = A + 2
        for _ in range(5):
            A = A + 8
        for _ in range(3):
            A = A + 2
            A = A + 9
        A = A + 6
        A = A + 3
    for _ in range(5):
        for _ in range(6):
            A = A + 5
            A = A + 5
        for _ in range(4):
            A = A + 5
        A = A + 4
        for _ in range(8):
            A = A + 9
            A = A + 1
        for _ in range(8):
            A = A + 8
            A = A + 1
        A = A + 4
        for _ in range(6):
            A = A + 6
        for _ in range(2):
            A = A + 3
            A = A + 9
            A = A + 6
            A = A + 9
        for _ in range(1):
            A = A + 4
        for _ in range(3):
            A = A + 3
            A = A + 4
            A = A + 2
            A = A + 8
        for _ in range(2):
            A = A + 4
        A = A + 1
        for _ in range(9):
            A = A + 2
        A = A + 9
    A = A + 7
for _ in range(7):
    for _ in range(7):
        for _ in range(5):
            A = A + 7
        for _ in range(5):
            A = A + 1
        A = A + 1
    for _ in range(5):
        A = A + 6
        for _ in range(1):
            A = A + 4
        for _ in range(9):
            A = A + 4
        A = A + 1
    for _ in range(6):
        A = A + 8
        A = A + 5
        for _ in range(1):
            A = A + 4
        for _ in range(5):
            A = A + 8
            A = A + 7
        A = A + 2
    for _ in range(3):
        A = A + 3
    for _ in range(8):
        for _ in range(8):
            A = A + 4
        A = A + 7
        for _ in range(5):
            A = A + 1
        for _ in range(8):
            A = A + 7
            A = A + 8
            A = A + 4
        A = A + 7
        A = A + 6
    A = A + 9
    A = A + 5
for _ in range(3):
    A = A + 5
    for _ in range(9):
        A = A + 1
    A = A + 7
for _ in range(1):
    A = A + 8
A = A + 4
for _ in range(8):
    for _ in range(7):
        A = A + 2
        for _ in range(4):
            A = A + 6
        A = A + 6
    for _ in range(1):
        A = A + 7
    A = A + 1
for _ in range(9):
    for _ in range(5):
        A = A + 6
        A = A + 5
        for _ in range(7):
            A = A + 3
            A = A + 6
        A = A + 8
    for _ in range(2):
        A = A + 7
    A = A + 1
    A = A + 9
    for _ in range(3):
        for _ in range(3):
            A = A + 5

print(A)

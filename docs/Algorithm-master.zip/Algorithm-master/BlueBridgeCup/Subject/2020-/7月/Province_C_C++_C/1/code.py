if __name__ == '__main__':
    print((7 ** 2020) % 1921)

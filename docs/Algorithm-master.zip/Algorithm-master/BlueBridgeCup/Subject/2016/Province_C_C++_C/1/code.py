#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time     : 2020/2/16 13:58
# @File     : BubbleSortCode.py
# ----------------------------------------------
# ☆ ☆ ☆ ☆ ☆ ☆ ☆ 
# >>> Author    : Alex
# >>> QQ        : 2426671397
# >>> Mail      : alex18812649207@gmail.com
# >>> Github    : https://github.com/koking0
# ☆ ☆ ☆ ☆ ☆ ☆ ☆
"""
1125,1126,1727,1728

报纸的4个页码累加之后除以2减去1就是报纸的总页数
"""
print(((1125 + 1126 + 1727 + 1728) / 2) - 1)

n = input()
print(int(n, 16))
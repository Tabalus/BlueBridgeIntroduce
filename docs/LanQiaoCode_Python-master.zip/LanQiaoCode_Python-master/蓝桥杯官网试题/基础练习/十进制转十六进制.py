n = int(input())
print(format(n, 'X'))
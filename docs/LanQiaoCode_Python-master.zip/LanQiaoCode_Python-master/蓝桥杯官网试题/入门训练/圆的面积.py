r = int(input())
PI=3.14159265358979323
area = (r**2) * PI
print('%.7f' % area)

## 2020年蓝桥杯省赛模拟赛-Python题解
[2020年蓝桥杯省赛模拟赛-Python题解](https://blog.csdn.net/qq_43442524/article/details/105610900):`https://blog.csdn.net/qq_43442524/article/details/105610900`
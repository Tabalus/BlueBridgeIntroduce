ans = 0
for i in range(1, 131):
    ans += pow(i, 2)
print(ans)

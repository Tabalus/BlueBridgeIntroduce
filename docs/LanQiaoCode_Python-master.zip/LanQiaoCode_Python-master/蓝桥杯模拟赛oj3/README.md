## Python算法学习: 竞码编程-蓝桥杯模拟赛3题解
[Python算法学习: 竞码编程-蓝桥杯模拟赛3题解](https://blog.csdn.net/qq_43442524/article/details/104591827)
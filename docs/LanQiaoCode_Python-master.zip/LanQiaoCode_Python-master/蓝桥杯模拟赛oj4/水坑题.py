a,b = map(int, input().split())
ans = (a*b) % (pow(10,9)+7)
print(ans)
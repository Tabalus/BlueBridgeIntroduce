n = int(input())

if n % 2 == 0:
    print("no")
else:
    print("yes")

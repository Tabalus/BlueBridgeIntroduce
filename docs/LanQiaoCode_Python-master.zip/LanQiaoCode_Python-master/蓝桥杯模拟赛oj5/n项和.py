n=int(input())
print((n*(n+1)//2%1000000007))

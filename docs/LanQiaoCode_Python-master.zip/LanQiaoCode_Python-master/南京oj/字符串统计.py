while True:
    num = 0
    var = input()
    aim = input()
    num = var.count(aim)
    print(num)


n = int(input())
print(2 ** (n - 1))
# LanQiaoCode_Python

![](https://pic.downk.cc/item/5ecf25ebc2a9a83be5ba0765.png)

喜欢作者麻烦点个star支持一下吧

蓝桥杯官网VIP试题,历届真题,模拟赛代码**Python**实现与讲解

详细代码讲解思路与题目介绍可以参考我的博客:⭐

[Python算法学习: 蓝桥杯官方省赛真题(持续更新)-CSDN](https://blog.csdn.net/qq_43442524/article/details/104188100)

[Python算法学习: 蓝桥杯官方省赛真题(持续更新)](https://plutoacharon.github.io/2020/02/23/Python%E7%AE%97%E6%B3%95%E5%AD%A6%E4%B9%A0-%E8%93%9D%E6%A1%A5%E6%9D%AF%E5%AE%98%E6%96%B9%E7%9C%81%E8%B5%9B%E7%9C%9F%E9%A2%98-%E6%8C%81%E7%BB%AD%E6%9B%B4%E6%96%B0/)

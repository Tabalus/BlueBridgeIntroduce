package basic;

import java.util.Scanner;

/**
 * @Auther: xuzhangwang
 * @Description: 蓝桥杯基础练习 矩形面积交
 */
public class T1471 {
    public static void main(String[] args) {

    }
}

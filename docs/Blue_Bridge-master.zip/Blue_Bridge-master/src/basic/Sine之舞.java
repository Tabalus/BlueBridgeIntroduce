package basic;

import java.util.Scanner;

/**
 * @Auther: xuzhangwang
 * @Description: 题目看不懂。。。
 */
public class Sine之舞 {
    public static void main(String[] args) {

    }



}

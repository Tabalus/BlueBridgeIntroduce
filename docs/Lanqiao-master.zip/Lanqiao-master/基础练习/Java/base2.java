package algorithm.Lanqiao.基础练习;

public class base2 {
    public static void main(String[] args) {
        for (int i = 0; i <= 1; i++) {
            for (int j = 0; j < 2; j++) {
                for (int j2 = 0; j2 < 2; j2++) {
                    for (int k = 0; k < 2; k++) {
                        for (int k2 = 0; k2 < 2; k2++) {
                            System.out.println(String.valueOf(i) + String.valueOf(j) + String.valueOf(j2) + String.valueOf(k) + String.valueOf(k2));
                        }

                    }
                }
            }

        }
    }
}

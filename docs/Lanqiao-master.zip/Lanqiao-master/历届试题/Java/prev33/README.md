历届试题 兰顿蚂蚁
<img src="http://lx.lanqiao.org/problem.page?gpid=T125" />
集合运算 蓝桥OJ
<img src="screenshot-lx.lanqiao.org 2015-11-30 21-26-33">
<article>
    这里有个坑就是输入的n，可能会出现大于20或小于0的值
</article>
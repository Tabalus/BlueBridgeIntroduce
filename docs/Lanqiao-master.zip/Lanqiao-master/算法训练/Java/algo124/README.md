算法训练  数字三角形
<img src="screenshot-lx.lanqiao.org 2015-12-07 07-45-27.png">
#include <iostream>
using namespace std;
int main() {
    cout << "yes";
    return 0;
}
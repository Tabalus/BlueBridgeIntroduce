#include <iostream>
using namespace std;
int main() {
    string s1, s2;
    cin >> s1 >> s2;
    cout << s1 << s2;
    return 0;
}
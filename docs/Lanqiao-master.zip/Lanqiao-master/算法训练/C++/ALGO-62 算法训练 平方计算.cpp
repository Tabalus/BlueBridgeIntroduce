#include <iostream>
using namespace std;
int main() {
    int a, m;
    cin >> a >> m;
    cout << (a * a) % m << endl;
    return 0;
}
#include <iostream>
using namespace std;
int main() {
    cout << "Nine-by-nine Multiplication Table" << endl;
    cout << "--------------------------------------" << endl;
    cout << "     1   2   3   4   5   6   7   8   9" << endl;
    cout << "--------------------------------------" << endl;
    cout << " 1   1\n2   2   4\n3   3   6   9\n4   4   8  12  16\n5   5  10  15  20  25\n6   6  12  18  24  30  36\n";
    cout << "7   7  14  21  28  35  42  49\n8   8  16  24  32  40  48  56  64\n9   9  18  27  36  45  54  63  72  81\n";
    cout << "--------------------------------------";
    return 0;
}
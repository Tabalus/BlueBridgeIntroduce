#include <iostream>
#include <cstdio>
using namespace std;
int main() {
    double a, p;
    cin >> a >> b;
    double ans =a + a * b * 0.01 * 0.8;
    printf("%.2f", ans);
    return 0;
}
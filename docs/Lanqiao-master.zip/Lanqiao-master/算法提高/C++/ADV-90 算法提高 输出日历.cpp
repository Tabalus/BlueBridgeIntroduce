#include <iostream>
using namespace std;
int main() {
    cout << "Calendar 2006-12\n--------------------------\nSu  Mo  Tu  We  Th  Fr  Sa\n--------------------------\n";
    cout << "                     1   2\n 3   4   5   6   7   8   9\n10  11  12  13  14  15  16\n17  18  19  20  21  22  23\n";
    cout << "24  25  26  27  28  29  30\n31\n--------------------------";
    return 0;
}
#include <iostream>
using namespace std;
int main() {
    double ans;
    double a, b;
    cin >> a >> b;
    ans = (0 - b) / a;
    printf("%.2lf", ans);
    return 0;
}
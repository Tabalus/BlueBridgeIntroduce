#include <iostream>
#include <cstdio>
using namespace std;
int main() {
    int a;
    cin >> a;
    double b = a * 1.8 + 32;
    printf("%.2f", b);
    return 0;
}
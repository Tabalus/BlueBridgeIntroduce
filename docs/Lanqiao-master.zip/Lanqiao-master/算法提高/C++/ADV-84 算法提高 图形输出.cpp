#include <iostream>
using namespace std;
int main() {
    cout << " X | X | X" << endl << "---+---+---" << endl << "   |   |   " << endl << "---+---+---" << endl << " O | O | O" << endl;
    return 0;
}
#include <iostream>
using namespace std;
int main() {
    cout << "---------------------------------------------------\nCOUNTRY     AREA(10K km2)  POP.(10K)  GDP(Billion$)\n---------------------------------------------------\nChina              960.00  129500.00  1080.00\n";
    cout << "Iceland             10.30      27.57  8.20\nIndia              297.47   97000.00  264.80\nMadagascar          62.70    1635.00  3.60\nMaldive            0.0298      27.80  0.23\n";
    cout << "---------------------------------------------------\n";
    return 0;
}
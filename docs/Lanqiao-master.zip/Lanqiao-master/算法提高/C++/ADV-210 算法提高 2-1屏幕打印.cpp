#include <iostream>
using namespace std;
int main() {
    cout << "**********************\n* My first C program *\n**********************";
    return 0;
}
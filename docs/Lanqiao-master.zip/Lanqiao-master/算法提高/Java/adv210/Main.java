package adv210;

public class Main {

	public static void main(String[] args) {
		System.out.println("**********************");
		System.out.println("* My first C program *");
		System.out.println("**********************");
	}

}
